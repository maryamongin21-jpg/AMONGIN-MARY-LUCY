%% Stormwater Management Tool
% Run this script and enter values when prompted

clear; clc; close all;

fprintf('=== STORMWATER ANALYSIS TOOL ===\n\n');

%% Step 1: Catchment Basic Information
fprintf('STEP 1: CATCHMENT INFORMATION\n');
fprintf('-----------------------------\n');

catchment_name = input('Enter catchment name: ', 's');
if isempty(catchment_name)
    catchment_name = 'My Catchment';
end

area = input('Enter catchment area (km²) [default: 2.5]: ');
if isempty(area)
    area = 2.5;
end

impervious_ratio = input('Enter impervious ratio (0-1) [default: 0.65]: ');
if isempty(impervious_ratio)
    impervious_ratio = 0.65;
end

soil_infiltration = input('Enter soil infiltration rate (mm/hr) [default: 25]: ');
if isempty(soil_infiltration)
    soil_infiltration = 25;
end

drain_capacity = input('Enter drainage system capacity (m³/s) [default: 15]: ');
if isempty(drain_capacity)
    drain_capacity = 15;
end

%% Step 2: Rainfall Data Input
fprintf('\nSTEP 2: RAINFALL DATA\n');
fprintf('--------------------\n');

fprintf('Choose rainfall input method:\n');
fprintf('1 - Use default 24-hour storm\n');
fprintf('2 - Enter custom rainfall values\n');
choice = input('Enter choice [1]: ');

if isempty(choice) || choice == 1
    % Default rainfall pattern - FIXED: Ensure same length as time_hr
    time_hr = 0:0.5:24;
    % Make sure rainfall has exactly 49 elements (0:0.5:24 gives 49 points)
    rainfall = [0 0 2 8 15 25 35 28 22 18 12 8 5 3 2 1 zeros(1,33)]; % Fixed to 49 elements
    fprintf('Using default 24-hour storm pattern\n');
else
    duration = input('Enter storm duration (hours) [default: 24]: ');
    if isempty(duration)
        duration = 24;
    end
    
    interval = input('Enter time interval (hours) [default: 0.5]: ');
    if isempty(interval)
        interval = 0.5;
    end
    
    time_hr = 0:interval:duration;
    
    fprintf('Enter rainfall intensity (mm/hr) for each time step:\n');
    fprintf('Time range: 0 to %.1f hours, %.0f values needed\n', duration, length(time_hr));
    rainfall = zeros(1, length(time_hr));
    
    for i = 1:length(time_hr)
        rainfall(i) = input(sprintf('  Time %.1f hr: ', time_hr(i)));
    end
end

if length(time_hr) ~= length(rainfall)
    fprintf('Warning: Adjusting rainfall data to match time steps...\n');
    if length(time_hr) > length(rainfall)
        % Pad rainfall with zeros if shorter
        rainfall = [rainfall, zeros(1, length(time_hr) - length(rainfall))];
    else
        % Truncate rainfall if longer
        rainfall = rainfall(1:length(time_hr));
    end
end

%% Step 3: Management Scenarios
fprintf('\nSTEP 3: MANAGEMENT SCENARIOS\n');
fprintf('---------------------------\n');

fprintf('Use default scenarios?\n');
fprintf('1 - Yes (Current, Green Roofs, Permeable Pavement, Rain Gardens, Combined)\n');
fprintf('2 - No, enter custom scenarios\n');
scenario_choice = input('Enter choice [1]: ');

if isempty(scenario_choice) || scenario_choice == 1
    scenario_names = {'Current', 'Green Roofs', 'Permeable Pavement', 'Rain Gardens', 'Combined GI'};
    reduction_rates = [0, 0.15, 0.25, 0.20, 0.45];
    costs = [0, 1.2, 2.5, 1.8, 4.0];
else
    num_scenarios = input('How many scenarios? [default: 3]: ');
    if isempty(num_scenarios)
        num_scenarios = 3;
    end
    
    scenario_names = cell(1, num_scenarios);
    reduction_rates = zeros(1, num_scenarios);
    costs = zeros(1, num_scenarios);
    
    fprintf('Enter scenario details:\n');
    for i = 1:num_scenarios
        fprintf('\nScenario %d:\n', i);
        scenario_names{i} = input('  Name: ', 's');
        reduction_rates(i) = input('  Runoff reduction (0-1): ');
        costs(i) = input('  Cost (Million USD): ');
    end
end

%% Step 4: Run Calculations
fprintf('\nSTEP 4: RUNNING ANALYSIS...\n');
fprintf('---------------------------\n');

% Calculate runoff coefficient
C = 0.05 + 0.9 * impervious_ratio;
fprintf('Runoff coefficient: %.3f\n', C);

% Calculate runoff
runoff_volume = zeros(size(rainfall));
for i = 1:length(rainfall)
    if rainfall(i) > soil_infiltration
        runoff_volume(i) = C * (rainfall(i) - soil_infiltration) * area * 0.278;
    end
end

peak_runoff = max(runoff_volume);
utilization = (peak_runoff / drain_capacity) * 100;

% Calculate scenario results
reduced_runoff = zeros(length(scenario_names), length(runoff_volume));
peak_runoffs = zeros(1, length(scenario_names));
reduction_percents = reduction_rates * 100;
cost_effectiveness = zeros(1, length(scenario_names));

for i = 1:length(scenario_names)
    reduced_runoff(i,:) = runoff_volume * (1 - reduction_rates(i));
    peak_runoffs(i) = max(reduced_runoff(i,:));
    if costs(i) > 0
        cost_effectiveness(i) = reduction_percents(i) / costs(i);
    end
end

%% Step 5: Display Results
fprintf('\n=== ANALYSIS RESULTS ===\n');
fprintf('Catchment: %s\n', catchment_name);
fprintf('Area: %.1f km², Impervious: %.0f%%\n', area, impervious_ratio*100);
fprintf('Soil infiltration: %.0f mm/hr\n', soil_infiltration);
fprintf('Drain capacity: %.1f m³/s\n\n', drain_capacity);

fprintf('RAINFALL SUMMARY:\n');
fprintf('  Duration: %.1f hours\n', time_hr(end));
fprintf('  Peak intensity: %.1f mm/hr\n', max(rainfall));
fprintf('  Total rainfall: %.1f mm\n\n', sum(rainfall)*0.5);

fprintf('RUNOFF RESULTS:\n');
fprintf('  Peak runoff: %.2f m³/s\n', peak_runoff);
fprintf('  System utilization: %.1f%% of capacity\n', utilization);

if peak_runoff > drain_capacity
    fprintf('   STATUS: SYSTEM OVERLOADED - Flooding expected!\n');
    fprintf('  Excess capacity needed: %.2f m³/s\n', peak_runoff - drain_capacity);
else
    fprintf('  STATUS: SYSTEM ADEQUATE - No flooding expected\n');
    fprintf('  Safety margin: %.2f m³/s\n', drain_capacity - peak_runoff);
end

fprintf('\nSCENARIO COMPARISON:\n');
fprintf('%-20s %-8s %-8s %-8s %-12s\n', 'Scenario', 'Peak(m³/s)', 'Reduction%', 'Cost($M)', 'Eff(%/$M)');
fprintf('------------------------------------------------------------\n');
for i = 1:length(scenario_names)
    if i == 1
        fprintf('%-20s %-8.2f %-8s %-8.1f %-12s\n', ...
            scenario_names{i}, peak_runoffs(i), '-', costs(i), '-');
    else
        fprintf('%-20s %-8.2f %-8.0f %-8.1f %-12.1f\n', ...
            scenario_names{i}, peak_runoffs(i), reduction_percents(i), costs(i), cost_effectiveness(i));
    end
end

%% Step 6: Recommendations
fprintf('\n=== RECOMMENDATIONS ===\n');

% Find best scenarios
if length(scenario_names) > 1
    [~, best_effective] = max(reduction_percents(2:end));
    [~, best_cost_eff] = max(cost_effectiveness(2:end));
    
    fprintf(' Most effective: %s (%.0f%% reduction)\n', ...
        scenario_names{best_effective+1}, reduction_percents(best_effective+1));
    fprintf('Best value: %s (%.1f%% per $M)\n', ...
        scenario_names{best_cost_eff+1}, cost_effectiveness(best_cost_eff+1));
end

if peak_runoff > drain_capacity
    fprintf('\n URGENT ACTIONS NEEDED:\n');
    fprintf('   • Implement %s immediately\n', scenario_names{best_effective+1});
    fprintf('   • Increase drainage capacity by %.2f m³/s\n', peak_runoff - drain_capacity);
    fprintf('   • Install temporary flood barriers\n');
    fprintf('   • Update emergency response plans\n');
elseif utilization > 80
    fprintf('\n  PREVENTIVE ACTIONS RECOMMENDED:\n');
    fprintf('   • Plan implementation of %s\n', scenario_names{best_cost_eff+1});
    fprintf('   • Regular drainage maintenance\n');
    fprintf('   • Monitor system performance\n');
else
    fprintf('\n SYSTEM IS ADEQUATE:\n');
    fprintf('   • Focus on water quality improvements\n');
    fprintf('   • Consider %s for future resilience\n', scenario_names{best_cost_eff+1});
    fprintf('   • Regular system inspections\n');
end

%% Step 7: Visualization
fprintf('\nGenerating summary plot...\n');

figure('Position', [100, 100, 1000, 600]);

% Plot 1: Rainfall and Runoff - FIXED
subplot(2,2,1);
yyaxis left;
% Use bar with proper length checking
if length(time_hr) == length(rainfall)
    bar(time_hr, rainfall, 'FaceColor', [0.7 0.9 1], 'EdgeColor', 'none');
else
    % Fallback: use plot if lengths don't match
    plot(time_hr(1:length(rainfall)), rainfall, 'Color', [0.7 0.9 1], 'LineWidth', 2);
end
ylabel('Rainfall (mm/hr)');
yyaxis right;
plot(time_hr, runoff_volume, 'r-', 'LineWidth', 2);
hold on;
yline(drain_capacity, 'k--', 'LineWidth', 2, 'Label', 'Drain Capacity');
ylabel('Runoff (m³/s)');
title('Rainfall vs Runoff');
legend('Rainfall', 'Runoff', 'Location', 'northeast');
grid on;

% Plot 2: Scenario Comparison
subplot(2,2,2);
if ~isempty(scenario_names) && ~isempty(peak_runoffs)
    bar(categorical(scenario_names), peak_runoffs);
    hold on;
    yline(drain_capacity, 'r--', 'LineWidth', 2, 'Label', 'Capacity');
    title('Peak Runoff by Scenario');
    ylabel('Peak Runoff (m³/s)');
    xtickangle(45);
    grid on;
else
    text(0.5, 0.5, 'No scenario data', 'HorizontalAlignment', 'center');
    title('Scenario Comparison');
end

% Plot 3: Cost vs Effectiveness
subplot(2,2,3);
if length(scenario_names) > 1
    valid_idx = costs(2:end) > 0 & reduction_percents(2:end) > 0;
    if any(valid_idx)
        scatter(costs(2:end), reduction_percents(2:end), 100, 'filled');
        for i = 2:length(scenario_names)
            if i-1 <= length(valid_idx) && valid_idx(i-1)
                text(costs(i), reduction_percents(i), scenario_names{i}, ...
                    'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', 'FontSize', 8);
            end
        end
        xlabel('Cost (Million USD)');
        ylabel('Runoff Reduction (%)');
        title('Cost vs Effectiveness');
        grid on;
    else
        text(0.5, 0.5, 'No valid cost data', 'HorizontalAlignment', 'center');
        title('Cost vs Effectiveness');
    end
else
    text(0.5, 0.5, 'Multiple scenarios needed', 'HorizontalAlignment', 'center');
    title('Cost vs Effectiveness');
end

% Plot 4: System Status
subplot(2,2,4);
if peak_runoff > drain_capacity
    status_text = {' SYSTEM OVERLOADED', sprintf('%.1f%% above capacity', utilization-100), 'Flooding Expected'};
    color = 'red';
else
    status_text = {'SYSTEM ADEQUATE', sprintf('%.1f%% of capacity', utilization), 'No Flooding Expected'};
    color = 'green';
end
text(0.5, 0.7, status_text, 'HorizontalAlignment', 'center', ...
    'FontSize', 14, 'FontWeight', 'bold', 'Color', color);
text(0.5, 0.4, sprintf('Peak Runoff: %.2f m³/s', peak_runoff), ...
    'HorizontalAlignment', 'center', 'FontSize', 12);
text(0.5, 0.3, sprintf('Capacity: %.1f m³/s', drain_capacity), ...
    'HorizontalAlignment', 'center', 'FontSize', 12);
xlim([0 1]); ylim([0 1]);
set(gca, 'XTick', [], 'YTick', []);
title('System Status', 'FontSize', 14);
box on;

fprintf('\n Analysis complete! Check the figure for visual summary.\n');
fprintf('Results saved in workspace variables.\n');

%% Save variables to workspace for further use
assignin('base', 'catchment_name', catchment_name);
assignin('base', 'rainfall_data', rainfall);
assignin('base', 'time_data', time_hr);
assignin('base', 'runoff_results', runoff_volume);
assignin('base', 'scenario_names', scenario_names);
assignin('base', 'scenario_performance', peak_runoffs);