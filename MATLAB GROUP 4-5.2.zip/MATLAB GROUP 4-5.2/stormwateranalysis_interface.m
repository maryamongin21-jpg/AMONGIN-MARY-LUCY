function stormwateranalysis_interface
    % Create main figure window
    fig = uifigure('Name', 'Stormwater Management Analysis Tool', ...
                  'Position', [100 100 1200 700]);
    
    % Create tab group for organized layout
    tabgroup = uitabgroup(fig, 'Position', [10 10 1180 680]);
    
    % Input Tab
    input_tab = uitab(tabgroup, 'Title', 'Input Parameters');
    
    % Catchment Panel
    catchment_panel = uipanel(input_tab, 'Title', 'Catchment Information', ...
                             'Position', [20 450 560 200]);
    
    uilabel(catchment_panel, 'Position', [20 150 120 22], 'Text', 'Catchment Name:');
    name_edit = uieditfield(catchment_panel, 'text', 'Position', [150 150 150 22], ...
                           'Value', 'My Catchment');
    
    uilabel(catchment_panel, 'Position', [20 110 120 22], 'Text', 'Area (km²):');
    area_edit = uieditfield(catchment_panel, 'numeric', 'Position', [150 110 150 22], ...
                           'Value', 2.5);
    
    uilabel(catchment_panel, 'Position', [20 70 120 22], 'Text', 'Impervious Ratio:');
    imperv_edit = uieditfield(catchment_panel, 'numeric', 'Position', [150 70 150 22], ...
                             'Limits', [0 1], 'Value', 0.65);
    
    uilabel(catchment_panel, 'Position', [320 150 120 22], 'Text', 'Soil Infil. (mm/hr):');
    soil_edit = uieditfield(catchment_panel, 'numeric', 'Position', [450 150 80 22], ...
                           'Value', 25);
    
    uilabel(catchment_panel, 'Position', [320 110 120 22], 'Text', 'Drain Capacity (m³/s):');
    drain_edit = uieditfield(catchment_panel, 'numeric', 'Position', [450 110 80 22], ...
                            'Value', 15);
    
    % Rainfall Panel
    rainfall_panel = uipanel(input_tab, 'Title', 'Rainfall Data', ...
                            'Position', [20 250 560 180]);
    
    rainfall_dropdown = uidropdown(rainfall_panel, 'Position', [20 130 200 22], ...
                                  'Items', {'Default 24-hour storm', 'Custom rainfall'});
    
    uilabel(rainfall_panel, 'Position', [20 100 200 22], 'Text', 'Custom Rainfall (mm/hr):');
    rainfall_table = uitable(rainfall_panel, 'Position', [20 20 520 70], ...
                           'ColumnEditable', true, 'ColumnName', {'Time (hr)', 'Intensity'}, ...
                           'Data', [0:0.5:24; zeros(1,49)]');
    
    % Scenarios Panel
    scenario_panel = uipanel(input_tab, 'Title', 'Management Scenarios', ...
                            'Position', [20 20 560 210]);
    
    scenario_dropdown = uidropdown(scenario_panel, 'Position', [20 160 200 22], ...
                                  'Items', {'Default scenarios', 'Custom scenarios'});
    
    scenario_table = uitable(scenario_panel, 'Position', [20 20 520 120], ...
                           'ColumnEditable', true, ...
                           'ColumnName', {'Scenario', 'Reduction %', 'Cost ($M)'}, ...
                           'Data', {'Current', 0, 0; 'Green Roofs', 15, 1.2});
    
    % Analysis Button
    uibutton(input_tab, 'push', 'Position', [600 20 150 30], ...
                          'Text', 'Run Analysis', 'ButtonPushedFcn', @run_analysis);
    
    % Results Tab
    results_tab = uitab(tabgroup, 'Title', 'Analysis Results');
    
    % Results Text Area
    results_text = uitextarea(results_tab, 'Position', [20 350 560 300], ...
                             'Editable', false, 'FontName', 'Consolas');
    
    % Plot Area
    ax1 = uiaxes(results_tab, 'Position', [600 350 560 300]);
    ax2 = uiaxes(results_tab, 'Position', [600 20 560 300]);
    
    % Callback function for analysis
    function run_analysis(~, ~)
        try
            % Gather input data
            catchment_name = name_edit.Value;
            area = area_edit.Value;
            impervious_ratio = imperv_edit.Value;
            soil_infiltration = soil_edit.Value;
            drain_capacity = drain_edit.Value;
            
            % Process rainfall data
            if strcmp(rainfall_dropdown.Value, 'Default 24-hour storm')
                time_hr = 0:0.5:24;
                rainfall = [0 0 2 8 15 25 35 28 22 18 12 8 5 3 2 1 zeros(1,33)];
            else
                table_data = rainfall_table.Data;
                time_hr = table_data(:,1)';
                rainfall = table_data(:,2)';
            end
            
            % Process scenario data
            scenario_data = scenario_table.Data;
            scenario_names = scenario_data(:,1)';
            reduction_rates = [scenario_data{:,2}]/100;
            costs = [scenario_data{:,3}];
            
            % Perform calculations
            C = 0.05 + 0.9 * impervious_ratio;
            
            runoff_volume = zeros(size(rainfall));
            for i = 1:length(rainfall)
                if rainfall(i) > soil_infiltration
                    runoff_volume(i) = C * (rainfall(i) - soil_infiltration) * area * 0.278;
                end
            end
            
            peak_runoff = max(runoff_volume);
            utilization = (peak_runoff / drain_capacity) * 100;
            
            % Calculate scenario results
            peak_runoffs = zeros(1, length(scenario_names));
            for i = 1:length(scenario_names)
                reduced_runoff = runoff_volume * (1 - reduction_rates(i));
                peak_runoffs(i) = max(reduced_runoff);
            end
            
            % Display results
            result_str = sprintf('=== ANALYSIS RESULTS ===\n');
            result_str = [result_str sprintf('Catchment: %s\n', catchment_name)];
            result_str = [result_str sprintf('Area: %.1f km², Impervious: %.0f%%\n', area, impervious_ratio*100)];
            result_str = [result_str sprintf('Peak Runoff: %.2f m³/s\n', peak_runoff)];
            result_str = [result_str sprintf('System Utilization: %.1f%%\n\n', utilization)];
            
            if peak_runoff > drain_capacity
                result_str = [result_str sprintf('STATUS: SYSTEM OVERLOADED\n')];
                result_str = [result_str sprintf('Excess: %.2f m³/s\n', peak_runoff - drain_capacity)];
            else
                result_str = [result_str sprintf('STATUS: SYSTEM ADEQUATE\n')];
                result_str = [result_str sprintf('Margin: %.2f m³/s\n', drain_capacity - peak_runoff)];
            end
            
            result_str = [result_str sprintf('\nSCENARIO COMPARISON:\n')];
            for i = 1:length(scenario_names)
                result_str = [result_str sprintf('%-20s: %.2f m³/s\n', scenario_names{i}, peak_runoffs(i))];
            end
            
            results_text.Value = result_str;
            
            % Update plots
            plot(ax1, time_hr, rainfall, 'b-', 'LineWidth', 2);
            hold(ax1, 'on');
            yyaxis(ax1, 'right');
            plot(ax1, time_hr, runoff_volume, 'r-', 'LineWidth', 2);
            yline(ax1, drain_capacity, 'k--', 'LineWidth', 2);
            xlabel(ax1, 'Time (hours)');
            yyaxis(ax1, 'left'); ylabel(ax1, 'Rainfall (mm/hr)');
            yyaxis(ax1, 'right'); ylabel(ax1, 'Runoff (m³/s)');
            legend(ax1, 'Rainfall', 'Runoff', 'Capacity', 'Location', 'northeast');
            title(ax1, 'Rainfall-Runoff Hydrograph');
            grid(ax1, 'on');
            hold(ax1, 'off');
            
            bar(ax2, categorical(scenario_names), peak_runoffs);
            hold(ax2, 'on');
            yline(ax2, drain_capacity, 'r--', 'LineWidth', 2, 'Label', 'Capacity');
            ylabel(ax2, 'Peak Runoff (m³/s)');
            title(ax2, 'Scenario Comparison');
            grid(ax2, 'on');
            xtickangle(ax2, 45);
            
        catch ME
            errordlg(sprintf('Analysis error: %s', ME.message), 'Calculation Error');
        end
    end

    % Initialize custom rainfall table
    function init_rainfall_table(~, ~)
        if strcmp(rainfall_dropdown.Value, 'Custom rainfall')
            time_steps = (0:0.5:24)';
            intensities = zeros(size(time_steps));
            rainfall_table.Data = [time_steps, intensities];
        end
    end
    rainfall_dropdown.ValueChangedFcn = @init_rainfall_table;
    
    % Initialize scenario table based on selection
    function init_scenario_table(~, ~)
        if strcmp(scenario_dropdown.Value, 'Default scenarios')
            default_data = {
                'Current', 0, 0;
                'Green Roofs', 15, 1.2;
                'Permeable Pavement', 25, 2.5;
                'Rain Gardens', 20, 1.8;
                'Combined GI', 45, 4.0
            };
            scenario_table.Data = default_data;
        else
            scenario_table.Data = {'New Scenario', 10, 1.0};
        end
    end
    scenario_dropdown.ValueChangedFcn = @init_scenario_table;
    
    % Initialize tables
    init_rainfall_table();
    init_scenario_table();
end