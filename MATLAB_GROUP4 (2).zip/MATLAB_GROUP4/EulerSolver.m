classdef EulerSolver < DifferentialEquationSolver
    % EULERSOLVER Concrete implementation of Euler method
    
    methods
        function obj = EulerSolver(odeFun, tSpan, h, y0, analyticalFun, tolerance, maxIterations)
            obj = obj@DifferentialEquationSolver('Euler', odeFun, tSpan, h, y0, analyticalFun, tolerance, maxIterations);
        end
        
        function result = solve(obj)
            % Implement Euler method recursively
            tic;
            obj.validateParameters();
            
            [obj.timeVector, obj.solution] = obj.recursiveEuler(...
                obj.timeVector(1), obj.initialCondition, 1, obj.timeVector(1), obj.initialCondition);
            
            obj.calculateErrors();
            obj.computationTime = toc;
            
            result = struct('time', obj.timeVector, 'solution', obj.solution, ...
                          'max_error', obj.maxError, 'time_elapsed', obj.computationTime);
        end
        
        function [t_array, y_array] = recursiveEuler(obj, t_current, y_current, step, t_array, y_array)
            % Recursive Euler implementation
            if t_current >= obj.timeVector(end)
                return;
            end
            
            t_next = t_current + obj.stepSize;
            if t_next > obj.timeVector(end)
                t_next = obj.timeVector(end);
                h_actual = t_next - t_current;
            else
                h_actual = obj.stepSize;
            end
            
            % Euler calculation
            y_next = y_current + h_actual * obj.odeFunction(t_current, y_current);
            
            % Store results
            t_array(step + 1) = t_next;
            y_array(step + 1) = y_next;
            
            if mod(step, 10) == 0
                fprintf('  Step %d: t = %.2f, y = %.6f\n', step, t_next, y_next);
            end
            
            % Recursive call
            [t_array, y_array] = obj.recursiveEuler(t_next, y_next, step + 1, t_array, y_array);
        end
    end
end