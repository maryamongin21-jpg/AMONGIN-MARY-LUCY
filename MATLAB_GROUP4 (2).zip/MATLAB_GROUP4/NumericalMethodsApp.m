classdef NumericalMethodsApp
    % NUMERICALMETHODSAPP Main application controller
    % Demonstrates polymorphism and class hierarchy usage
    
    properties
        rootSolvers
        odeSolvers
        results
    end
    
    methods
        function obj = NumericalMethodsApp()
            obj.rootSolvers = {};
            obj.odeSolvers = {};
            obj.results = struct();
        end
        
        function obj = runRootFindingAnalysis(obj)
            % Run root finding analysis using polymorphism
            fprintf('\n=== ROOT FINDING ANALYSIS ===\n');
            
            % Define the problem: f(r) = (8/3)*pi*r - 2000/r^2
            f = @(r) (8/3)*pi*r - 2000./(r.^2);
            df = @(r) (8/3)*pi + 4000./(r.^3);
            
            % Create different solvers (polymorphism in action)
            newtonSolver = NewtonRaphsonSolver(f, df, 10, 1e-8, 100);
            bisectionSolver = BisectionSolver(f, 5, 15, 1e-8, 100);
            secantSolver = SecantSolver(f, 5, 15, 1e-8, 100);
            
            obj.rootSolvers = {newtonSolver, bisectionSolver, secantSolver};
            
            % Solve using each method (same interface, different implementations)
            rootResults = [];
            for i = 1:length(obj.rootSolvers)
                solver = obj.rootSolvers{i};
                fprintf('\n--- Solving with %s ---\n', solver.name);
                try
                    result = solver.solve();
                    solver.displayResults();
                    solver.plotConvergence();
                    rootResults = [rootResults, result];
                catch ME
                    fprintf('  ✗ Error in %s: %s\n', solver.name, ME.message);
                end
            end
            
            obj.results.rootFinding = rootResults;
            obj.plotRootFindingComparison();
        end
        
        function obj = runODEAnalysis(obj)
            % Run ODE analysis using polymorphism
            fprintf('\n=== ODE SOLVING ANALYSIS ===\n');
            
            % Define the ODE problem: dy/dt = -k*y, y(0) = y0
            k = 0.5;
            y0 = 100;
            dydt = @(t, y) -k*y;
            analytical = @(t) y0 * exp(-k*t);
            
            % Create different ODE solvers (polymorphism)
            rk4Solver = RungeKutta4Solver(dydt, [0, 10], 0.1, y0, analytical, 1e-6, 1000);
            rk2Solver = RungeKutta2Solver(dydt, [0, 10], 0.1, y0, analytical, 1e-6, 1000);
            eulerSolver = EulerSolver(dydt, [0, 10], 0.1, y0, analytical, 1e-6, 1000);
            
            obj.odeSolvers = {rk4Solver, rk2Solver, eulerSolver};
            
            % Solve using each method
            odeResults = [];
            for i = 1:length(obj.odeSolvers)
                solver = obj.odeSolvers{i};
                fprintf('\n--- Solving with %s ---\n', solver.name);
                try
                    result = solver.solve();
                    solver.displayResults();
                    solver.plotComparison();
                    odeResults = [odeResults, result];
                catch ME
                    fprintf('  ✗ Error in %s: %s\n', solver.name, ME.message);
                end
            end
            
            obj.results.odeSolving = odeResults;
            obj.plotODEComparison();
        end
        
        function plotRootFindingComparison(obj)
            % Compare root finding methods
            if isfield(obj.results, 'rootFinding') && ~isempty(obj.results.rootFinding)
                figure('Position', [100, 100, 1200, 800]);
                
                % Get method names
                methodNames = {};
                for i = 1:length(obj.rootSolvers)
                    if i <= length(obj.results.rootFinding)
                        methodNames{end+1} = obj.rootSolvers{i}.name;
                    end
                end
                
                subplot(2,3,1);
                roots = [obj.results.rootFinding.root];
                bar(roots);
                set(gca, 'XTickLabel', methodNames);
                ylabel('Root Value');
                title('Root Comparison');
                grid on;
                
                subplot(2,3,2);
                iterations = [obj.results.rootFinding.iterations];
                bar(iterations);
                set(gca, 'XTickLabel', methodNames);
                ylabel('Iterations');
                title('Iteration Count');
                grid on;
                
                subplot(2,3,3);
                times = [obj.results.rootFinding.time];
                bar(times);
                set(gca, 'XTickLabel', methodNames);
                ylabel('Computation Time (s)');
                title('Computation Time');
                grid on;
                
                subplot(2,3,4);
                % Plot function and roots
                r_plot = linspace(5, 15, 1000);
                f = @(r) (8/3)*pi*r - 2000./(r.^2);
                plot(r_plot, f(r_plot), 'b-', 'LineWidth', 2);
                hold on;
                colors = ['r', 'g', 'm'];
                for i = 1:length(obj.results.rootFinding)
                    root = obj.results.rootFinding(i).root;
                    plot(root, f(root), [colors(i) 'o'], 'MarkerSize', 10, 'LineWidth', 3, ...
                         'DisplayName', [methodNames{i} ' (r=' sprintf('%.6f', root) ')']);
                end
                xlabel('r');
                ylabel('f(r)');
                title('Function with Roots');
                legend('Location', 'best');
                grid on;
                
                subplot(2,3,5);
                % Plot convergence history
                hold on;
                colors = ['r', 'g', 'b'];
                for i = 1:length(obj.rootSolvers)
                    if i <= length(obj.results.rootFinding)
                        solver = obj.rootSolvers{i};
                        if ~isempty(solver.history)
                            plot(1:length(solver.history), solver.history, [colors(i) '-o'], ...
                                'LineWidth', 1.5, 'MarkerSize', 4, 'DisplayName', solver.name);
                        end
                    end
                end
                xlabel('Iteration');
                ylabel('Solution Value');
                title('Convergence History');
                legend('Location', 'best');
                grid on;
                
                subplot(2,3,6);
                % Plot error convergence
                hold on;
                for i = 1:length(obj.rootSolvers)
                    if i <= length(obj.results.rootFinding)
                        solver = obj.rootSolvers{i};
                        if ~isempty(solver.errorHistory)
                            semilogy(1:length(solver.errorHistory), abs(solver.errorHistory), [colors(i) '-s'], ...
                                    'LineWidth', 1.5, 'MarkerSize', 4, 'DisplayName', solver.name);
                        end
                    end
                end
                xlabel('Iteration');
                ylabel('Absolute Error');
                title('Error Convergence (log scale)');
                legend('Location', 'best');
                grid on;
            end
        end
        
        function plotODEComparison(obj)
            % Compare ODE solving methods
            if isfield(obj.results, 'odeSolving') && ~isempty(obj.results.odeSolving)
                figure('Position', [100, 100, 1200, 800]);
                
                % Get method names
                methodNames = {};
                for i = 1:length(obj.odeSolvers)
                    if i <= length(obj.results.odeSolving)
                        methodNames{end+1} = obj.odeSolvers{i}.name;
                    end
                end
                
                subplot(2,3,1);
                max_errors = [obj.results.odeSolving.max_error];
                bar(max_errors);
                set(gca, 'XTickLabel', methodNames, 'YScale', 'log');
                ylabel('Maximum Error');
                title('Maximum Errors (log scale)');
                grid on;
                
                subplot(2,3,2);
                times = [obj.results.odeSolving.time_elapsed];
                bar(times);
                set(gca, 'XTickLabel', methodNames);
                ylabel('Computation Time (s)');
                title('Computation Time');
                grid on;
                
                subplot(2,3,3);
                % Plot all solutions together
                colors = ['r', 'g', 'b', 'm'];
                hold on;
                for i = 1:length(obj.odeSolvers)
                    if i <= length(obj.results.odeSolving)
                        solver = obj.odeSolvers{i};
                        plot(solver.timeVector, solver.solution, [colors(i) '-'], ...
                             'LineWidth', 2, 'DisplayName', solver.name);
                    end
                end
                % Add analytical solution
                t_fine = linspace(0, 10, 1000);
                analytical = @(t) 100 * exp(-0.5*t);
                plot(t_fine, analytical(t_fine), 'k--', 'LineWidth', 1, 'DisplayName', 'Analytical');
                xlabel('Time');
                ylabel('y(t)');
                title('ODE Solutions Comparison');
                legend('Location', 'best');
                grid on;
                
                subplot(2,3,4);
                % Plot errors over time
                hold on;
                for i = 1:length(obj.odeSolvers)
                    if i <= length(obj.results.odeSolving)
                        solver = obj.odeSolvers{i};
                        if ~isempty(solver.errorHistory)
                            plot(solver.timeVector, solver.errorHistory, [colors(i) '-'], ...
                                 'LineWidth', 1.5, 'DisplayName', [solver.name ' Error']);
                        end
                    end
                end
                xlabel('Time');
                ylabel('Absolute Error');
                title('Errors Over Time');
                legend('Location', 'best');
                grid on;
                
                subplot(2,3,5);
                % Plot error distributions
                hold on;
                for i = 1:length(obj.odeSolvers)
                    if i <= length(obj.results.odeSolving)
                        solver = obj.odeSolvers{i};
                        if ~isempty(solver.errorHistory)
                            histogram(solver.errorHistory, 20, 'FaceColor', colors(i), ...
                                     'FaceAlpha', 0.6, 'DisplayName', solver.name);
                        end
                    end
                end
                xlabel('Error Magnitude');
                ylabel('Frequency');
                title('Error Distribution');
                legend('Location', 'best');
                grid on;
                
                subplot(2,3,6);
                % Plot relative errors
                hold on;
                for i = 1:length(obj.odeSolvers)
                    if i <= length(obj.results.odeSolving)
                        solver = obj.odeSolvers{i};
                        if ~isempty(solver.analyticalSolution) && ~isempty(solver.solution)
                            analytical_values = solver.analyticalSolution(solver.timeVector);
                            relative_errors = solver.errorHistory ./ abs(analytical_values);
                            plot(solver.timeVector, relative_errors, [colors(i) '-'], ...
                                 'LineWidth', 1.5, 'DisplayName', [solver.name ' Relative Error']);
                        end
                    end
                end
                xlabel('Time');
                ylabel('Relative Error');
                title('Relative Errors Over Time');
                legend('Location', 'best');
                grid on;
            end
        end
        
        function demonstratePolymorphism(obj)
            % Demonstrate polymorphism with the class hierarchy
            fprintf('\n=== POLYMORPHISM DEMONSTRATION ===\n');
            
            allSolvers = [obj.rootSolvers, obj.odeSolvers];
            
            for i = 1:length(allSolvers)
                solver = allSolvers{i};
                fprintf('\nSolver %d:\n', i);
                fprintf('  Type: %s\n', class(solver));
                fprintf('  Name: %s\n', solver.name);
                fprintf('  Solver Type: %s\n', solver.SOLVER_TYPE);
                
                % Polymorphic method calls
                solver.displayResults();
            end
        end
    end
end