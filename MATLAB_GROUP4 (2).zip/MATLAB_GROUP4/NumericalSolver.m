classdef (Abstract) NumericalSolver
    % NUMERICALSOLVER Abstract base class for all numerical solvers
    % Implements abstraction and common functionality
    
    properties (Abstract, Constant)
        SOLVER_TYPE    % Must be defined by subclasses
    end
    
    properties
        name
        tolerance
        maxIterations
        computationTime
        iterations
        history
        errorHistory
    end
    
    properties (Access = protected)
        problemFunction
        hasConverged
    end
    
    methods (Abstract)
        % Abstract methods that must be implemented by subclasses
        solve(obj)
        validateParameters(obj)
        displayResults(obj)
    end
    
    methods
        function obj = NumericalSolver(name, tolerance, maxIterations)
            % Constructor for base class
            if nargin > 0
                obj.name = name;
                obj.tolerance = tolerance;
                obj.maxIterations = maxIterations;
                obj.computationTime = 0;
                obj.iterations = 0;
                obj.history = [];
                obj.errorHistory = [];
                obj.hasConverged = false;
            end
        end
        
        function convergence = checkConvergence(obj, currentError, iteration)
            % Common convergence checking method
            convergence = (currentError < obj.tolerance) || (iteration >= obj.maxIterations);
            obj.hasConverged = convergence;
        end
        
        function recordHistory(obj, value, error)
            % Record iteration history
            obj.history = [obj.history, value];
            obj.errorHistory = [obj.errorHistory, error];
        end
        
        function plotConvergence(obj)
            % Common convergence plotting method
            if ~isempty(obj.history)
                figure;
                subplot(2,1,1);
                plot(1:length(obj.history), obj.history, 'b-o', 'LineWidth', 2, 'MarkerSize', 4);
                xlabel('Iteration');
                ylabel('Solution Value');
                title([obj.name ' - Solution History']);
                grid on;
                
                subplot(2,1,2);
                semilogy(1:length(obj.errorHistory), abs(obj.errorHistory), 'r-s', 'LineWidth', 2, 'MarkerSize', 4);
                xlabel('Iteration');
                ylabel('Absolute Error');
                title([obj.name ' - Error Convergence']);
                grid on;
            end
        end
    end
end