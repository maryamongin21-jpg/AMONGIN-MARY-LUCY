%% MAIN SCRIPT - Numerical Methods Application
% Demonstrates OOP concepts: Abstraction, Inheritance, Polymorphism
% Includes: Newton-Raphson, Bisection, Secant, RK4, RK2, Euler methods

clear; clc; 

fprintf('=== HIGH-END NUMERICAL METHODS APPLICATION ===\n');
fprintf('Implementing: Abstraction, Inheritance, Polymorphism\n\n');

% Create the main application controller
app = NumericalMethodsApp();

% Run root finding analysis (now with 3 methods)
fprintf('\n>>> Starting Root Finding Analysis with 3 Methods...\n');
app = app.runRootFindingAnalysis();

% Run ODE analysis (now with 3 methods)
fprintf('\n>>> Starting ODE Solving Analysis with 3 Methods...\n');
app = app.runODEAnalysis();

% Demonstrate polymorphism
fprintf('\n>>> Demonstrating Polymorphism...\n');
app.demonstratePolymorphism();

fprintf('\n=== APPLICATION COMPLETED SUCCESSFULLY ===\n');
fprintf('Root Finding Methods Implemented:\n');
fprintf('  1. Newton-Raphson Method\n');
fprintf('  2. Bisection Method\n');
fprintf('  3. Secant Method\n');
fprintf('\nODE Solving Methods Implemented:\n');
fprintf('  1. Runge-Kutta 4th Order (RK4)\n');
fprintf('  2. Runge-Kutta 2nd Order (RK2)\n');
fprintf('  3. Euler Method\n');
fprintf('\nKey OOP Concepts Demonstrated:\n');
fprintf('  1. ABSTRACTION: Abstract base classes define common interfaces\n');
fprintf('  2. INHERITATION: Subclasses inherit from abstract base classes\n');
fprintf('  3. POLYMORPHISM: Same interface, different implementations\n');
fprintf('  4. ENCAPSULATION: Data and methods bundled in classes\n');