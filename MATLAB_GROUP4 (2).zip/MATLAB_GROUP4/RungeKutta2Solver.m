classdef RungeKutta2Solver < DifferentialEquationSolver
    % RUNGEKUTTA2SOLVER Concrete implementation of RK2 method (Heun's method)
    
    methods
        function obj = RungeKutta2Solver(odeFun, tSpan, h, y0, analyticalFun, tolerance, maxIterations)
            obj = obj@DifferentialEquationSolver('Runge-Kutta 2', odeFun, tSpan, h, y0, analyticalFun, tolerance, maxIterations);
        end
        
        function result = solve(obj)
            % Implement RK2 method recursively
            tic;
            obj.validateParameters();
            
            [obj.timeVector, obj.solution] = obj.recursiveRK2(...
                obj.timeVector(1), obj.initialCondition, 1, obj.timeVector(1), obj.initialCondition);
            
            obj.calculateErrors();
            obj.computationTime = toc;
            
            result = struct('time', obj.timeVector, 'solution', obj.solution, ...
                          'max_error', obj.maxError, 'time_elapsed', obj.computationTime);
        end
        
        function [t_array, y_array] = recursiveRK2(obj, t_current, y_current, step, t_array, y_array)
            % Recursive RK2 implementation (Heun's method)
            if t_current >= obj.timeVector(end)
                return;
            end
            
            t_next = t_current + obj.stepSize;
            if t_next > obj.timeVector(end)
                t_next = obj.timeVector(end);
                h_actual = t_next - t_current;
            else
                h_actual = obj.stepSize;
            end
            
            % RK2 calculations (Heun's method)
            k1 = h_actual * obj.odeFunction(t_current, y_current);
            k2 = h_actual * obj.odeFunction(t_current + h_actual, y_current + k1);
            
            y_next = y_current + (k1 + k2) / 2;
            
            % Store results
            t_array(step + 1) = t_next;
            y_array(step + 1) = y_next;
            
            if mod(step, 10) == 0
                fprintf('  Step %d: t = %.2f, y = %.6f\n', step, t_next, y_next);
            end
            
            % Recursive call
            [t_array, y_array] = obj.recursiveRK2(t_next, y_next, step + 1, t_array, y_array);
        end
    end
end