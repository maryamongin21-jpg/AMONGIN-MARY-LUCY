classdef RungeKutta4Solver < DifferentialEquationSolver
    % RUNGEKUTTA4SOLVER Concrete implementation of RK4 method
    
    methods
        function obj = RungeKutta4Solver(odeFun, tSpan, h, y0, analyticalFun, tolerance, maxIterations)
            obj = obj@DifferentialEquationSolver('Runge-Kutta 4', odeFun, tSpan, h, y0, analyticalFun, tolerance, maxIterations);
        end
        
        function result = solve(obj)
            % Implement RK4 method recursively
            tic;
            obj.validateParameters();
            
            [obj.timeVector, obj.solution] = obj.recursiveRK4(...
                obj.timeVector(1), obj.initialCondition, 1, obj.timeVector(1), obj.initialCondition);
            
            obj.calculateErrors();
            obj.computationTime = toc;
            
            result = struct('time', obj.timeVector, 'solution', obj.solution, ...
                          'max_error', obj.maxError, 'time_elapsed', obj.computationTime);
        end
        
        function [t_array, y_array] = recursiveRK4(obj, t_current, y_current, step, t_array, y_array)
            % Recursive RK4 implementation
            if t_current >= obj.timeVector(end)
                return;
            end
            
            t_next = t_current + obj.stepSize;
            if t_next > obj.timeVector(end)
                t_next = obj.timeVector(end);
                h_actual = t_next - t_current;
            else
                h_actual = obj.stepSize;
            end
            
            % RK4 calculations
            k1 = h_actual * obj.odeFunction(t_current, y_current);
            k2 = h_actual * obj.odeFunction(t_current + h_actual/2, y_current + k1/2);
            k3 = h_actual * obj.odeFunction(t_current + h_actual/2, y_current + k2/2);
            k4 = h_actual * obj.odeFunction(t_current + h_actual, y_current + k3);
            
            y_next = y_current + (k1 + 2*k2 + 2*k3 + k4) / 6;
            
            % Store results
            t_array(step + 1) = t_next;
            y_array(step + 1) = y_next;
            
            if mod(step, 10) == 0
                fprintf('  Step %d: t = %.2f, y = %.6f\n', step, t_next, y_next);
            end
            
            % Recursive call
            [t_array, y_array] = obj.recursiveRK4(t_next, y_next, step + 1, t_array, y_array);
        end
    end
end